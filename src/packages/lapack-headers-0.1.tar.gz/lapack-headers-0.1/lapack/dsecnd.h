#ifdef __cplusplus
extern "C" double dsecnd_(
	);
#else /* ! __cplusplus */
double dsecnd_(
	);
#endif /* ! __cplusplus */

