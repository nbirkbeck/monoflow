#ifdef __cplusplus
extern "C" double dlamch_(
	const char &cmach		// (input)
	);
#else /* ! __cplusplus */
double dlamch_(
	const char *cmach		/* (input) */
	);
#endif /* ! __cplusplus */

