#ifdef __cplusplus
extern "C" float second_(
	);
#else /* ! __cplusplus */
float second_(
	);
#endif /* ! __cplusplus */

